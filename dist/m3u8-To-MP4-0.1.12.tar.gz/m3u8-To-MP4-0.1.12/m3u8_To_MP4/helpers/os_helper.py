# -*- coding: utf-8 -*-
import os

def get_core_count():
    return os.cpu_count()

